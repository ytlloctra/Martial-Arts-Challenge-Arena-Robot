#ifndef __FILTER_H
#define __FILTER_H
#include "sys.h"

void filter(void);
#endif