#ifndef __EDGE_H
#define __EDGE_H
#include "sys.h"

#define EDGE GPIOD->IDR
#define FEDGE GPIOB->IDR
#define fedge1 PDin(1)
#define fedge2 PDin(0)
#define bedge1 PDin(11)
#define bedge2 PDin(3)
void edge_init(void);
#endif
