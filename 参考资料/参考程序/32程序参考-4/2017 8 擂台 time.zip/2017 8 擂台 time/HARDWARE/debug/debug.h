#ifndef __DEBUG_H
#define __DEBUG_H	
#include "sys.h" 

void change(u8 gg,u8 gg1);
void change1(u8 gg,u8 gg1);
#endif
	