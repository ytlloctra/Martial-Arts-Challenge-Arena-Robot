#ifndef __MYOLED_H
#define __MYOLED_H	 
#include "myoled.h"
#include "oled.h"
#include "optoelectronic_switch.h"
#include "delay.h"

void GD_oled(void);
void normal_oled(void);
//void test_oled(void);
//void ranking_oled(void);
//void weedout_oled(void);
//void enter_test_oled(void);
//void enter_ranking_oled(void);
//void enter_weedout_oled(void);
//void pitch_oled(void);
//void yaw_oled(void);
//void roll_oled(void);
//void temp_oled(void);
//void cpu_oled(void);
//void zzsp_oled(void);
//void GDJC_oled(void);
//void FSJC_oled(void);
//void HDJC_oled(void);
//void enter_HDJC_oled(void);
//void enter_GDJC_oled(void);
//void enter_FSJC_oled(void);
//void GJMS_oled(void);
//void FYMS_oled(void);
//void BBMS_oled(void);
//void enter_GJMS_oled(void);
//void enter_FYMS_oled(void);
//void enter_BBMS_oled(void);



#endif


